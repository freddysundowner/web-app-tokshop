import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import { fileURLToPath } from 'url';
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";

// Compatible with older Node.js versions
const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...(process.env.NODE_ENV !== "production" &&
    process.env.REPL_ID !== undefined
      ? [
          await import("@replit/vite-plugin-cartographer").then((m) =>
            m.cartographer(),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "client", "src"),
      "@shared": path.resolve(__dirname, "../shared-backend/shared"),
      "@assets": path.resolve(__dirname, "../attached_assets"),
      // Explicitly map zod to app's node_modules so imports from @shared can find it
      "zod": path.resolve(__dirname, "node_modules/zod"),
    },
    // Ensure dependencies are resolved from app's node_modules
    preserveSymlinks: false,
  },
  optimizeDeps: {
    // Pre-bundle zod so it's available when importing from @shared
    include: ['zod'],
  },
  root: path.resolve(__dirname, "client"),
  build: {
    outDir: path.resolve(__dirname, "dist/public"),
    emptyOutDir: true,
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"],
    },
  },
});
